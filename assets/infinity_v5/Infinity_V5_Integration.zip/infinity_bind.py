import argparse, numpy as np, pandas as pd, trimesh
from scipy.spatial import cKDTree
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('mesh');p.add_argument('channels');p.add_argument('output');p.add_argument('--rgb-frame',help='Raw channel bytes, one byte per channel, from decoded FSEQ frame');a=p.parse_args()
s=trimesh.load(a.mesh,force='scene');d=pd.read_csv(a.channels);rgb=d[['red_channel','green_channel','blue_channel']].to_numpy()-1
assert np.array_equal(rgb.ravel(),np.arange(len(d)*3))
frame=np.fromfile(a.rgb_frame,dtype=np.uint8) if a.rgb_frame else np.full(len(d)*3,255,np.uint8)
assert len(frame)>=len(d)*3
worst=0; count=0
for m,g in d.groupby('model'):
 nodes=[n for n in s.graph.nodes_geometry if s.graph[n][1]==m];assert len(nodes)==1,m
 mesh=s.geometry[m];v=trimesh.transform_points(mesh.vertices,s.graph[nodes[0]][0]);xyz=g[['x_m','z_m','y_m']].to_numpy();xyz[:,2]*=-1
 dist,idx=cKDTree(xyz).query(v);assert dist.max()<0.25,(m,dist.max());assert len(np.unique(idx))==len(g),m
 colors=frame[rgb[g.index.to_numpy()[idx]]];mesh.visual=trimesh.visual.ColorVisuals(mesh=mesh,vertex_colors=np.column_stack([colors,np.full(len(colors),255,np.uint8)]));worst=max(worst,float(dist.max()));count+=len(g)
s.export(a.output);print(f'Bound {count} pixels across {d.model.nunique()} models; maximum vertex distance {worst:.4f} m')
