Christmas Overdrive — NATIVE CONCEPT SHOW

105 independent Custom pixel models; 14920 pixels; 44760 channels.
Use this folder as an independent xLights show. Open Christmas_Overdrive_Showcase.xsq, Render All, then play.
Pinned validation version: xLights 2026.18. The study is 24 seconds, silent, and is not a full-song music sequence.
All source artwork, original shows and source drummer files are preserved. No physical output networks.
models/ contains every reusable native model; model_inventory.csv lists absolute channel ranges.
Editable SECTOR_00–07, structure-specific submodels and zone groups are available for sequencing.
Artwork reference: assets/concept_reference.png (left panel).
Limit: High prop density and repeated patterns need visual separation and realistic power/channel planning.
The emitted contours are a planning interpretation. Scenic water, people, beams, vehicle bodywork and stonework are not pixel meshes.
Stage drummer demonstration does not establish source-song transcription or drummer acceptance.
