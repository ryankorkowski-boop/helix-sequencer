Interference Reef — NATIVE CONCEPT SHOW

18 independent Custom pixel models; 5731 pixels; 17193 channels.
Use this folder as an independent xLights show. Open Interference_Reef_Showcase.xsq, Render All, then play.
Pinned validation version: xLights 2026.18. The study is 24 seconds, silent, and is not a full-song music sequence.
All source artwork, original shows and source drummer files are preserved. No physical output networks.
models/ contains every reusable native model; model_inventory.csv lists absolute channel ranges.
Editable SECTOR_00–07, structure-specific submodels and zone groups are available for sequencing.
Artwork reference: assets/concept_reference.png (right panel).
Limit: Refraction is a lighting/overlap illusion; mesh density, sightlines and flicker need review.
The emitted contours are a planning interpretation. Scenic water, people, beams, vehicle bodywork and stonework are not pixel meshes.
Stage drummer demonstration does not establish source-song transcription or drummer acceptance.
