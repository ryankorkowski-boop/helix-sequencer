Impala Neon Royalty — NATIVE CONCEPT SHOW

79 independent Custom pixel models; 4944 pixels; 14832 channels.
Use this folder as an independent xLights show. Open Impala_Neon_Royalty_Showcase.xsq, Render All, then play.
Pinned validation version: xLights 2026.18. The study is 24 seconds, silent, and is not a full-song music sequence.
All source artwork, original shows and source drummer files are preserved. No physical output networks.
models/ contains every reusable native model; model_inventory.csv lists absolute channel ranges.
Editable SECTOR_00–07, structure-specific submodels and zone groups are available for sequencing.
Artwork reference: assets/concept_reference.png (left panel).
Limit: An accurate car mesh/reference is needed; static wheel lights are concept-only and moving wheel wiring is unresolved.
The emitted contours are a planning interpretation. Scenic water, people, beams, vehicle bodywork and stonework are not pixel meshes.
Stage drummer demonstration does not establish source-song transcription or drummer acceptance.
