Thunder Vault Stage — NATIVE CONCEPT SHOW

42 independent Custom pixel models; 16126 pixels; 48378 channels.
Use this folder as an independent xLights show. Open Thunder_Vault_Stage_Showcase.xsq, Render All, then play.
Pinned validation version: xLights 2026.18. The study is 24 seconds, silent, and is not a full-song music sequence.
All source artwork, original shows and source drummer files are preserved. No physical output networks.
models/ contains every reusable native model; model_inventory.csv lists absolute channel ranges.
Editable SECTOR_00–07, structure-specific submodels and zone groups are available for sequencing.
Artwork reference: assets/concept_reference.png (right panel).
Limit: DMX behavior, sightlines and show control require dedicated design beyond RGB pixel placement.
The emitted contours are a planning interpretation. Scenic water, people, beams, vehicle bodywork and stonework are not pixel meshes.
Stage drummer demonstration does not establish source-song transcription or drummer acceptance.
