Silent lighting study; no soundtrack is required. Copy original song media here when authoring a matching music XSQ.
