Bioluminescent Mangrove — NATIVE CONCEPT SHOW

57 independent Custom pixel models; 6945 pixels; 20835 channels.
Use this folder as an independent xLights show. Open Bioluminescent_Mangrove_Showcase.xsq, Render All, then play.
Pinned validation version: xLights 2026.18. The study is 24 seconds, silent, and is not a full-song music sequence.
All source artwork, original shows and source drummer files are preserved. No physical output networks.
models/ contains every reusable native model; model_inventory.csv lists absolute channel ranges.
Editable SECTOR_00–07, structure-specific submodels and zone groups are available for sequencing.
Artwork reference: assets/concept_reference.png (left panel).
Limit: Canopies and path structures need load and access review; glowing wetlands are lighting scenery.
The emitted contours are a planning interpretation. Scenic water, people, beams, vehicle bodywork and stonework are not pixel meshes.
Stage drummer demonstration does not establish source-song transcription or drummer acceptance.
